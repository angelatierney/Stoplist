Angela Tierney 

Milestones 
-------------------------------
1. Create classes 
- CLI
- Document 
- Driver 
- SearchEngine
- StopList 

2. Code for SearchEngine
- created the attributes and constructor 
- created the methods 
- needed a helper method 

3. Code for StopList
- attributes and constructor 
- create method isStopWord method 

4. Code for Document 
- attributes and constructor 
- create methods that override

5. Code for CLI
- proccess the command line arguments 
- loop through to see if verbose is there
- my CLI is taking the arguments and then returing the parsed arguments  
- return the parsedArgs

6. Code for Driver 
- created a try catch 
- in the try i error check if it a list 
- i was getting multiple errorrs with the elements list and had to att @SupressWarning("unchecked") 
- my Driver is taking the arguments and error checking 
- if it doesnt work my catch throws an exception 

7. Compile and debug 
- checking my code 
- constant error with my class Driver class so I had to add extra error chekcing 
- I had to debug my StopList class to help fix the output of my code

8. Test cases 
- I tested if my query worked 
- I added text files to see if other words worked and hwo verbose worked on other files 

